<?php

/**
 * @package     plg_system_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Joomla\Plugin\System\StealthWatch\Extension\StealthWatch;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $config = (array) PluginHelper::getPlugin('system', 'stealthwatch');

                // Joomla 6 dropped the dispatcher constructor argument; Joomla 5 still expects it.
                if (version_compare(JVERSION, '6.0.0-dev', '>=')) {
                    $plugin = new StealthWatch($config);
                } else {
                    $plugin = new StealthWatch($container->get(DispatcherInterface::class), $config);
                }

                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(DatabaseInterface::class));

                return $plugin;
            }
        );
    }
};
