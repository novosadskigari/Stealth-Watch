<?php

/**
 * @package     plg_system_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Plugin\System\StealthWatch\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Access\Exception\NotAllowed;
use Joomla\CMS\Cache\CacheControllerFactoryInterface;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\Component\StealthWatch\Administrator\Helper\AccessHelper;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\Component\StealthWatch\Administrator\Helper\ProtectionHelper;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

/**
 * 1. Watch:   snapshot plugin states at request start, diff at request end, log changes.
 * 2. Guard:   before Joomla runs the task, block disabling/uninstalling protected
 *             extensions and block non-managers from Stealth Watch's options.
 * 3. Revert:  if a protected plugin still ended up disabled (e.g. JCH's own dashboard
 *             toggle), switch it straight back on at the end of the request.
 *
 * All settings live in Components > Stealth Watch > Options.
 */
final class StealthWatch extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;

    /** @var array<int, object>|null */
    private ?array $pluginsBefore = null;

    private ?array $jchParamsBefore = null;

    private bool $checked = false;

    private ?Registry $settings = null;

    private ?bool $isManager = null;

    public static function getSubscribedEvents(): array
    {
        return [
            'onAfterInitialise' => 'takeSnapshot',
            'onAfterRoute'      => 'guardRequest',
            'onAfterRespond'    => 'detectChanges',
        ];
    }

    /* ---------------------------------------------------------------------
     * 1. Watch
     * ------------------------------------------------------------------- */

    public function takeSnapshot(): void
    {
        if (!$this->componentAvailable()) {
            return;
        }

        $app       = $this->getApplication();
        $isBackend = $app->isClient('administrator') || $app->isClient('api');

        if (!$isBackend && !$this->settings()->get('monitor_site', 0)) {
            return;
        }

        try {
            $this->pluginsBefore   = $this->loadPluginStates();
            $this->jchParamsBefore = $this->loadJchParams();
        } catch (\Throwable $e) {
            $this->pluginsBefore = null;

            return;
        }

        // Redirects call exit() and skip onAfterRespond; a shutdown function always runs.
        register_shutdown_function([$this, 'detectChanges']);
    }

    public function detectChanges(): void
    {
        if ($this->checked || $this->pluginsBefore === null) {
            return;
        }

        $this->checked = true;

        // The extension may have been uninstalled during this very request.
        if (!$this->componentAvailable()) {
            return;
        }

        try {
            $pluginsAfter   = $this->loadPluginStates();
            $jchParamsAfter = $this->loadJchParams();
            $logEnables     = (bool) $this->settings()->get('log_enables', 1);

            foreach ($this->pluginsBefore as $id => $old) {
                $new = $pluginsAfter[$id] ?? null;

                if ($new === null) {
                    $this->recordPlugin('uninstalled', $old);
                    continue;
                }

                $wasOn = (int) $old->enabled === 1;
                $isOn  = (int) $new->enabled === 1;

                if ($wasOn && !$isOn) {
                    if (ProtectionHelper::isProtected($new, $this->isManager())) {
                        $this->reEnable((int) $id);
                        $this->recordPlugin('reverted', $new, 'disable');
                    } elseif (ProtectionHelper::isProtected($new, false)) {
                        // Protected for everyone else, but this Settings Manager may bypass it.
                        $this->recordPlugin('override', $new, 'disable (protection bypassed by Settings Manager)');
                    } else {
                        $this->recordPlugin('disabled', $new);
                    }
                } elseif (!$wasOn && $isOn && $logEnables) {
                    $this->recordPlugin('enabled', $new);
                }
            }

            if ($this->jchParamsBefore !== null && $jchParamsAfter !== null) {
                $keys = array_unique(array_merge(array_keys($this->jchParamsBefore), array_keys($jchParamsAfter)));

                foreach ($keys as $key) {
                    if (stripos((string) $key, 'cache') === false) {
                        continue;
                    }

                    $oldValue = json_encode($this->jchParamsBefore[$key] ?? null);
                    $newValue = json_encode($jchParamsAfter[$key] ?? null);

                    if ($oldValue !== $newValue) {
                        $this->recordJchSetting((string) $key, $oldValue, $newValue);
                    }
                }
            }
        } catch (\Throwable $e) {
            // Never break a request because of the watcher.
        }
    }

    /* ---------------------------------------------------------------------
     * 2. Guard
     * ------------------------------------------------------------------- */

    public function guardRequest(): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('administrator') || !$this->componentAvailable()) {
            return;
        }

        $user = $app->getIdentity();

        if (!$user || !$user->id) {
            return;
        }

        $input  = $app->getInput();
        $option = $input->getCmd('option', '');
        $task   = strtolower($input->getCmd('task', ''));

        if (!\in_array($option, ['com_config', 'com_plugins', 'com_installer'], true)) {
            return;
        }

        $this->loadLanguage();

        if ($option === 'com_config') {
            $this->guardOptions();

            return;
        }

        if ($option === 'com_plugins') {
            if (str_ends_with($task, 'unpublish')) {
                $this->filterIds('disable', 'index.php?option=com_plugins&view=plugins');
            } elseif (\in_array($task, ['plugin.save', 'plugin.apply'], true)) {
                $this->guardPluginForm();
            }

            return;
        }

        // com_installer: Extensions > Manage
        if ($task === 'manage.unpublish') {
            $this->filterIds('disable', 'index.php?option=com_installer&view=manage');
        } elseif ($task === 'manage.remove') {
            $this->filterIds('uninstall', 'index.php?option=com_installer&view=manage');
        }
    }

    /**
     * Only Settings Managers may open/save Stealth Watch options or change its permissions.
     */
    private function guardOptions(): void
    {
        if ($this->isManager()) {
            return;
        }

        $input  = $this->getApplication()->getInput();
        $target = $input->getCmd('component', '') ?: $input->getCmd('comp', '');

        if ($target === '') {
            try {
                // The permissions tab saves via AJAX with a JSON body.
                $target = (string) $input->json->getCmd('comp', '');
            } catch (\Throwable $e) {
                $target = '';
            }
        }

        if ($target !== 'com_stealthwatch') {
            return;
        }

        $this->logBlocked(null, 'open or change options/permissions', Text::_('PLG_SYSTEM_STEALTHWATCH_OPTIONS_TITLE'));
        $this->deny(Text::_('PLG_SYSTEM_STEALTHWATCH_BLOCKED_OPTIONS'), 'index.php?option=com_stealthwatch&view=logs');
    }

    /**
     * Plugin edit form: keep protected plugins enabled, let other changes through.
     */
    private function guardPluginForm(): void
    {
        $input = $this->getApplication()->getInput();
        $id    = $input->getInt('extension_id');
        $data  = $input->post->get('jform', [], 'array');

        if (!$id || !isset($data['enabled']) || (int) $data['enabled'] === 1) {
            return;
        }

        $ext = $this->loadExtensions([$id])[$id] ?? null;

        if (!$ext || !ProtectionHelper::isProtected($ext, $this->isManager())) {
            return;
        }

        $data['enabled'] = 1;
        $input->post->set('jform', $data);

        $this->logBlocked($ext, 'disable');
        $this->getApplication()->enqueueMessage(
            Text::sprintf('PLG_SYSTEM_STEALTHWATCH_BLOCKED_FORM', $this->extensionTitle($ext)),
            'warning'
        );
    }

    /**
     * Remove protected extension IDs from "cid" before the controller runs.
     */
    private function filterIds(string $attempt, string $redirect): void
    {
        $input = $this->getApplication()->getInput();
        $ids   = array_values(array_filter(array_map('intval', (array) $input->get('cid', [], 'array'))));

        if (!$ids) {
            return;
        }

        $extensions = $this->loadExtensions($ids);
        $isManager  = $this->isManager();
        $allowed    = [];
        $blocked    = [];

        foreach ($ids as $id) {
            $ext = $extensions[$id] ?? null;

            if ($ext && ProtectionHelper::isProtected($ext, $isManager)) {
                $blocked[] = $ext;
            } else {
                $allowed[] = $id;
            }
        }

        if (!$blocked) {
            return;
        }

        foreach ($blocked as $ext) {
            $this->logBlocked($ext, $attempt);
        }

        $names   = implode(', ', array_map(fn (object $e): string => $this->extensionTitle($e), $blocked));
        $message = Text::sprintf('PLG_SYSTEM_STEALTHWATCH_BLOCKED_EXTENSIONS', $names);

        if (!$allowed) {
            $this->deny($message, $redirect);
        }

        $input->set('cid', $allowed);
        $input->post->set('cid', $allowed);
        $this->getApplication()->enqueueMessage($message, 'warning');
    }

    private function deny(string $message, string $redirect): void
    {
        $app = $this->getApplication();

        if ($app->getInput()->getCmd('format', 'html') !== 'html') {
            throw new NotAllowed($message, 403);
        }

        $app->enqueueMessage($message, 'error');
        $app->redirect(Route::_($redirect, false));
    }

    /* ---------------------------------------------------------------------
     * 3. Revert
     * ------------------------------------------------------------------- */

    private function reEnable(int $id): void
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('extension_id') . ' = :id')
            ->bind(':id', $id, ParameterType::INTEGER);

        $db->setQuery($query)->execute();

        try {
            Factory::getContainer()
                ->get(CacheControllerFactoryInterface::class)
                ->createCacheController('callback', ['defaultgroup' => 'com_plugins'])
                ->clean();
        } catch (\Throwable $e) {
            // Cache cleaning is best effort.
        }
    }

    /* ---------------------------------------------------------------------
     * Helpers
     * ------------------------------------------------------------------- */

    private function componentAvailable(): bool
    {
        return class_exists(LogHelper::class)
            && class_exists(AccessHelper::class)
            && class_exists(ProtectionHelper::class);
    }

    private function settings(): Registry
    {
        return $this->settings ??= ComponentHelper::getParams('com_stealthwatch');
    }

    private function isManager(): bool
    {
        return $this->isManager ??= AccessHelper::isManager($this->getApplication()->getIdentity());
    }

    /**
     * @return array<int, object>
     */
    private function loadPluginStates(): array
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select($db->quoteName(['extension_id', 'type', 'name', 'folder', 'element', 'enabled']))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));

        return $db->setQuery($query)->loadObjectList('extension_id') ?: [];
    }

    /**
     * @return array<int, object>
     */
    private function loadExtensions(array $ids): array
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select($db->quoteName(['extension_id', 'type', 'name', 'folder', 'element', 'enabled']))
            ->from($db->quoteName('#__extensions'))
            ->whereIn($db->quoteName('extension_id'), array_map('intval', $ids));

        return $db->setQuery($query)->loadObjectList('extension_id') ?: [];
    }

    private function loadJchParams(): ?array
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select($db->quoteName('params'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('com_jchoptimize'));

        $params = $db->setQuery($query)->loadResult();

        if ($params === null) {
            return null;
        }

        $decoded = json_decode((string) $params, true);

        return \is_array($decoded) ? $decoded : [];
    }

    private function recordPlugin(string $action, object $plugin, string $attempt = ''): void
    {
        $tag   = ProtectionHelper::jchTag($plugin);
        $title = $this->extensionTitle($plugin);

        $this->store(
            [
                'action'       => $action,
                'severity'     => (\in_array($action, ['reverted', 'override'], true) || ($action !== 'enabled' && $tag !== '')) ? 1 : 0,
                'tag'          => $tag,
                'extension_id' => (int) $plugin->extension_id,
                'title'        => $title,
                'folder'       => $plugin->folder,
                'element'      => $plugin->element,
                'old_value'    => $attempt,
            ],
            'PLG_SYSTEM_STEALTHWATCH_ACTION_' . strtoupper($action),
            [
                'action'   => $action,
                'id'       => (int) $plugin->extension_id,
                'title'    => $title,
                'folder'   => $plugin->folder,
                'element'  => $plugin->element,
                'itemlink' => 'index.php?option=com_plugins&task=plugin.edit&extension_id=' . (int) $plugin->extension_id,
            ]
        );
    }

    private function recordJchSetting(string $key, string $old, string $new): void
    {
        $this->store(
            [
                'action'    => 'setting',
                'severity'  => 1,
                'tag'       => 'jch_setting',
                'title'     => 'com_jchoptimize: ' . $key,
                'old_value' => $old,
                'new_value' => $new,
            ],
            'PLG_SYSTEM_STEALTHWATCH_ACTION_JCH_SETTING',
            [
                'action'   => 'update',
                'title'    => $key,
                'oldvalue' => $old,
                'newvalue' => $new,
                'itemlink' => 'index.php?option=com_jchoptimize',
            ]
        );
    }

    private function logBlocked(?object $ext, string $attempt, string $title = ''): void
    {
        $entry = ['action' => 'blocked', 'severity' => 1, 'old_value' => $attempt, 'title' => $title];

        if ($ext) {
            $entry['tag']          = ProtectionHelper::jchTag($ext);
            $entry['extension_id'] = (int) $ext->extension_id;
            $entry['title']        = $this->extensionTitle($ext);
            $entry['folder']       = (string) ($ext->folder ?? '');
            $entry['element']      = (string) $ext->element;
        }

        $this->store($entry, 'PLG_SYSTEM_STEALTHWATCH_ACTION_BLOCKED', [
            'action'   => 'blocked',
            'title'    => $entry['title'],
            'folder'   => $entry['folder'] ?? '',
            'element'  => $entry['element'] ?? '',
            'itemlink' => 'index.php?option=com_stealthwatch&view=logs',
        ]);
    }

    private function store(array $entry, string $actionLogKey, array $actionLogMessage): void
    {
        try {
            LogHelper::add($entry);
        } catch (\Throwable $e) {
            // Logging must never break the request.
        }

        if (!$this->settings()->get('use_actionlog', 0) || !ComponentHelper::isEnabled('com_actionlogs')) {
            return;
        }

        try {
            $app  = $this->getApplication();
            $user = $app->getIdentity();

            $actionLogMessage['userid']      = (int) ($user->id ?? 0);
            $actionLogMessage['username']    = $user->username ?? 'guest';
            $actionLogMessage['accountlink'] = 'index.php?option=com_users&task=user.edit&id=' . (int) ($user->id ?? 0);

            $app->bootComponent('com_actionlogs')
                ->getMVCFactory()
                ->createModel('Actionlog', 'Administrator', ['ignore_request' => true])
                ->addLog([$actionLogMessage], $actionLogKey, 'plg_system_stealthwatch', (int) ($user->id ?? 0));
        } catch (\Throwable $e) {
            // Optional secondary log only.
        }
    }

    private function extensionTitle(object $ext): string
    {
        $language = $this->getApplication()->getLanguage();
        $type     = (string) ($ext->type ?? 'plugin');
        $element  = (string) $ext->element;

        if ($type === 'plugin') {
            $extension = strtolower('plg_' . $ext->folder . '_' . $element);
            $language->load($extension . '.sys', JPATH_ADMINISTRATOR)
                || $language->load($extension . '.sys', JPATH_PLUGINS . '/' . $ext->folder . '/' . $element);
        } else {
            $language->load($element . '.sys', JPATH_ADMINISTRATOR);
        }

        return Text::_((string) $ext->name);
    }
}
