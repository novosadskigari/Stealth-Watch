<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Utilities\IpHelper;

/**
 * Writes entries to #__stealthwatch_log and enforces the retention settings.
 */
final class LogHelper
{
    public const TABLE = '#__stealthwatch_log';

    /**
     * Insert one log entry. User, IP, URL and timestamp are filled in automatically.
     *
     * @param array $data  action, severity, tag, extension_id, title, folder, element, old_value, new_value
     */
    public static function add(array $data): void
    {
        $app  = Factory::getApplication();
        $user = $app->getIdentity();

        $row = (object) [
            'created'      => Factory::getDate()->toSql(),
            'action'       => (string) ($data['action'] ?? ''),
            'severity'     => (int) ($data['severity'] ?? 0),
            'tag'          => (string) ($data['tag'] ?? ''),
            'extension_id' => (int) ($data['extension_id'] ?? 0),
            'title'        => mb_substr((string) ($data['title'] ?? ''), 0, 255),
            'folder'       => mb_substr((string) ($data['folder'] ?? ''), 0, 100),
            'element'      => mb_substr((string) ($data['element'] ?? ''), 0, 100),
            'old_value'    => isset($data['old_value']) ? (string) $data['old_value'] : '',
            'new_value'    => isset($data['new_value']) ? (string) $data['new_value'] : '',
            'user_id'      => (int) ($user->id ?? 0),
            'username'     => mb_substr((string) ($user->username ?? ''), 0, 150),
            'user_email'   => mb_substr((string) ($user->email ?? ''), 0, 100),
            'ip_address'   => mb_substr((string) IpHelper::getIp(), 0, 45),
            'client'       => mb_substr((string) $app->getName(), 0, 20),
            'url'          => Uri::getInstance()->toString(),
        ];

        self::db()->insertObject(self::TABLE, $row, 'id');

        self::purge();
    }

    /**
     * Delete entries older than the retention period and beyond the max count.
     *
     * @return int Number of deleted rows
     */
    public static function purge(): int
    {
        $params  = ComponentHelper::getParams('com_stealthwatch');
        $days    = max(0, (int) $params->get('retention_days', 90));
        $max     = max(0, (int) $params->get('max_entries', 1000));
        $db      = self::db();
        $deleted = 0;

        if ($days > 0) {
            $cutoff = Factory::getDate()->sub(new \DateInterval('P' . $days . 'D'))->toSql();

            $query = $db->createQuery()
                ->delete($db->quoteName(self::TABLE))
                ->where($db->quoteName('created') . ' < :cutoff')
                ->bind(':cutoff', $cutoff);

            $db->setQuery($query)->execute();
            $deleted += (int) $db->getAffectedRows();
        }

        if ($max > 0) {
            // Find the id of the first entry that falls outside the newest $max entries.
            $query = $db->createQuery()
                ->select($db->quoteName('id'))
                ->from($db->quoteName(self::TABLE))
                ->order($db->quoteName('id') . ' DESC');

            $threshold = (int) $db->setQuery($query, $max, 1)->loadResult();

            if ($threshold > 0) {
                $query = $db->createQuery()
                    ->delete($db->quoteName(self::TABLE))
                    ->where($db->quoteName('id') . ' <= :threshold')
                    ->bind(':threshold', $threshold, ParameterType::INTEGER);

                $db->setQuery($query)->execute();
                $deleted += (int) $db->getAffectedRows();
            }
        }

        return $deleted;
    }

    private static function db(): DatabaseInterface
    {
        return Factory::getContainer()->get(DatabaseInterface::class);
    }
}
