<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\User\User;
use Joomla\Database\DatabaseInterface;

/**
 * Settings Managers: an explicit list of users (Options -> Settings Managers)
 * who may change Stealth Watch options/permissions, disable or uninstall
 * Stealth Watch, and delete log entries.
 *
 * Safety net: if the list is empty, or none of the listed accounts still
 * exist and are unblocked, Joomla's normal ACL (core.admin on
 * com_stealthwatch, i.e. Super Users) applies, so nobody gets locked out.
 */
final class AccessHelper
{
    private static ?array $managerIds = null;

    /**
     * @return int[] IDs of listed managers that exist and are not blocked
     */
    public static function managerIds(): array
    {
        if (self::$managerIds !== null) {
            return self::$managerIds;
        }

        $raw = ComponentHelper::getParams('com_stealthwatch')->get('managers', []);
        $ids = [];

        foreach ((array) $raw as $row) {
            $id = (int) (((array) $row)['user_id'] ?? 0);

            if ($id > 0) {
                $ids[] = $id;
            }
        }

        $ids = array_values(array_unique($ids));

        if ($ids) {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->createQuery()
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__users'))
                ->whereIn($db->quoteName('id'), $ids)
                ->where($db->quoteName('block') . ' = 0');

            $ids = array_map('intval', $db->setQuery($query)->loadColumn() ?: []);
        }

        return self::$managerIds = $ids;
    }

    /**
     * @return string[] usernames of the active managers
     */
    public static function managerNames(): array
    {
        $ids = self::managerIds();

        if (!$ids) {
            return [];
        }

        $db    = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->createQuery()
            ->select($db->quoteName('username'))
            ->from($db->quoteName('#__users'))
            ->whereIn($db->quoteName('id'), $ids)
            ->order($db->quoteName('username'));

        return $db->setQuery($query)->loadColumn() ?: [];
    }

    public static function isManager(?User $user = null): bool
    {
        $user ??= Factory::getApplication()->getIdentity();

        if (!$user || !$user->id) {
            return false;
        }

        $ids = self::managerIds();

        if (!$ids) {
            return $user->authorise('core.admin', 'com_stealthwatch');
        }

        return \in_array((int) $user->id, $ids, true);
    }

    public static function canDeleteLogs(?User $user = null): bool
    {
        $user ??= Factory::getApplication()->getIdentity();

        if (!$user || !$user->authorise('core.delete', 'com_stealthwatch')) {
            return false;
        }

        if (ComponentHelper::getParams('com_stealthwatch')->get('restrict_log_delete', 1)) {
            return self::isManager($user);
        }

        return true;
    }
}
