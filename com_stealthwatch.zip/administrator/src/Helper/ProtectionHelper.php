<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;

/**
 * Rules for which extensions may not be disabled or uninstalled.
 *
 * Extension objects need: type, folder, element (rows from #__extensions).
 */
final class ProtectionHelper
{
    public static function isSelf(object $ext): bool
    {
        $type    = (string) ($ext->type ?? 'plugin');
        $element = (string) ($ext->element ?? '');

        return ($type === 'plugin' && ($ext->folder ?? '') === 'system' && $element === 'stealthwatch')
            || ($type === 'component' && $element === 'com_stealthwatch')
            || ($type === 'package' && $element === 'pkg_stealthwatch');
    }

    /**
     * '' (not JCH), 'jch' or 'jch_pagecache'
     */
    public static function jchTag(object $ext): string
    {
        $element = (string) ($ext->element ?? '');

        if (stripos($element, 'jch') === false) {
            return '';
        }

        $isPlugin = ((string) ($ext->type ?? 'plugin')) === 'plugin';

        return ($isPlugin && stripos($element, 'cache') !== false) ? 'jch_pagecache' : 'jch';
    }

    public static function isProtected(object $ext, bool $isManager): bool
    {
        $params = ComponentHelper::getParams('com_stealthwatch');
        $type   = (string) ($ext->type ?? 'plugin');

        // Stealth Watch itself: only Settings Managers may disable/uninstall it.
        if (self::isSelf($ext)) {
            return (bool) $params->get('protect_self', 1) && !$isManager;
        }

        // Settings Managers may deliberately disable protected plugins (logged as "Manager override").
        // Only explicitly listed managers count, never the Super User fallback.
        if ($isManager && $params->get('managers_bypass', 1) && AccessHelper::managerIds() !== []) {
            return false;
        }

        if ($params->get('protect_jch_pagecache', 1)) {
            // The page cache plugin itself.
            if ($type === 'plugin' && self::jchTag($ext) === 'jch_pagecache') {
                return true;
            }

            // Uninstalling/disabling the JCH component or package would also kill the page cache.
            if (\in_array($type, ['component', 'package'], true) && self::jchTag($ext) !== '') {
                return true;
            }
        }

        if ($type === 'plugin') {
            $key  = ($ext->folder ?? '') . '/' . ($ext->element ?? '');
            $list = array_map('strval', (array) $params->get('protected_plugins', []));

            if (\in_array($key, $list, true)) {
                return true;
            }
        }

        return false;
    }
}
