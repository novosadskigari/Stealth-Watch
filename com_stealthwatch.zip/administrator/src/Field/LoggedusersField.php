<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\Database\DatabaseInterface;

/**
 * Users that appear in the log, narrowed by the selected action and plugin.
 */
class LoggedusersField extends ListField
{
    protected $type = 'Loggedusers';

    protected function getOptions()
    {
        $db     = Factory::getContainer()->get(DatabaseInterface::class);
        $action = (string) $this->form->getValue('action', 'filter', '');
        $plugin = (string) $this->form->getValue('plugin', 'filter', '');

        $query = $db->createQuery()
            ->select([
                $db->quoteName('user_id'),
                'MAX(' . $db->quoteName('username') . ') AS ' . $db->quoteName('username'),
            ])
            ->from($db->quoteName(LogHelper::TABLE))
            ->group($db->quoteName('user_id'))
            ->order($db->quoteName('username') . ' ASC');

        if ($action === 'log') {
            $query->where($db->quoteName('action') . ' LIKE ' . $db->quote('log\_%'));
        } elseif ($action !== '') {
            $query->where($db->quoteName('action') . ' = :action')->bind(':action', $action);
        }

        if (str_contains($plugin, '/')) {
            [$folder, $element] = explode('/', $plugin, 2);
            $query->where($db->quoteName('folder') . ' = :folder')
                ->where($db->quoteName('element') . ' = :element')
                ->bind(':folder', $folder)
                ->bind(':element', $element);
        }

        $options = [];

        foreach ($db->setQuery($query)->loadObjectList() ?: [] as $row) {
            $label     = (int) $row->user_id > 0 ? $row->username : Text::_('COM_STEALTHWATCH_GUEST');
            $options[] = HTMLHelper::_('select.option', (string) (int) $row->user_id, $label);
        }

        return array_merge(parent::getOptions(), $options);
    }
}
