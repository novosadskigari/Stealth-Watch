<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\Database\DatabaseInterface;

/**
 * Plugins that appear in the log, narrowed by the currently selected action.
 */
class LoggedpluginsField extends ListField
{
    protected $type = 'Loggedplugins';

    protected function getOptions()
    {
        $db     = Factory::getContainer()->get(DatabaseInterface::class);
        $action = (string) $this->form->getValue('action', 'filter', '');

        $query = $db->createQuery()
            ->select([
                $db->quoteName('folder'),
                $db->quoteName('element'),
                'MAX(' . $db->quoteName('title') . ') AS ' . $db->quoteName('title'),
            ])
            ->from($db->quoteName(LogHelper::TABLE))
            ->where($db->quoteName('folder') . ' <> ' . $db->quote(''))
            ->group([$db->quoteName('folder'), $db->quoteName('element')])
            ->order($db->quoteName('title') . ' ASC');

        if ($action !== '' && $action !== 'log') {
            $query->where($db->quoteName('action') . ' = :action')->bind(':action', $action);
        }

        $options = [];

        foreach ($db->setQuery($query)->loadObjectList() ?: [] as $row) {
            $value     = $row->folder . '/' . $row->element;
            $options[] = HTMLHelper::_('select.option', $value, $row->title . ' (' . $value . ')');
        }

        return array_merge(parent::getOptions(), $options);
    }
}
