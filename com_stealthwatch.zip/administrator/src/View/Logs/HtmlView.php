<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\View\Logs;

\defined('_JEXEC') or die;

use Joomla\Component\StealthWatch\Administrator\Helper\AccessHelper;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

class HtmlView extends BaseHtmlView
{
    public array $items = [];

    public $pagination;

    public $state;

    public $filterForm;

    public array $activeFilters = [];

    public int $maxEntries = 0;

    public int $retentionDays = 0;

    public bool $protectJch = true;

    public bool $isManager = false;

    public array $managerNames = [];

    public function display($tpl = null): void
    {
        // Enforce retention every time the log is opened, so expired entries are never shown.
        try {
            LogHelper::purge();
        } catch (\Throwable $e) {
            // Listing still works if purging fails.
        }

        $params              = ComponentHelper::getParams('com_stealthwatch');
        $this->maxEntries    = (int) $params->get('max_entries', 1000);
        $this->retentionDays = (int) $params->get('retention_days', 90);
        $this->protectJch    = (bool) $params->get('protect_jch_pagecache', 1);
        $this->isManager     = AccessHelper::isManager();
        $this->managerNames  = AccessHelper::managerNames();

        $model               = $this->getModel();
        $this->items         = $model->getItems() ?: [];
        $this->pagination    = $model->getPagination();
        $this->state         = $model->getState();
        $this->filterForm    = $model->getFilterForm();
        $this->activeFilters = $model->getActiveFilters() ?: [];

        $this->addToolbar();

        parent::display($tpl);
    }

    protected function addToolbar(): void
    {
        ToolbarHelper::title(Text::_('COM_STEALTHWATCH'), 'eye');

        $canDo   = ContentHelper::getActions('com_stealthwatch');
        $toolbar = $this->getDocument()->getToolbar();

        if (AccessHelper::canDeleteLogs()) {
            $toolbar->delete('logs.delete')
                ->message('JGLOBAL_CONFIRM_DELETE')
                ->listCheck(true);

            $toolbar->standardButton('purge', 'COM_STEALTHWATCH_TOOLBAR_PURGE', 'logs.purge')
                ->icon('icon-refresh')
                ->listCheck(false);

            $toolbar->confirmButton('clear', 'COM_STEALTHWATCH_TOOLBAR_CLEAR', 'logs.clear')
                ->message('COM_STEALTHWATCH_CONFIRM_CLEAR')
                ->icon('icon-trash')
                ->listCheck(false);
        }

        // Options are only offered to Settings Managers (the plugin also blocks direct access).
        if ($this->isManager && ($canDo->get('core.admin') || $canDo->get('core.options'))) {
            $toolbar->preferences('com_stealthwatch');
        }
    }
}
