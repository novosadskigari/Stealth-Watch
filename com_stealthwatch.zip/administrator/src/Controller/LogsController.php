<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\Component\StealthWatch\Administrator\Helper\AccessHelper;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\Component\StealthWatch\Administrator\Model\LogsModel;
use Joomla\CMS\Access\Exception\NotAllowed;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

/**
 * Every manual removal of log entries is itself logged, so the log can't be
 * silently wiped by someone covering their tracks.
 */
class LogsController extends BaseController
{
    public function delete(): void
    {
        $this->checkToken();
        $this->assertCanDelete();

        $count = $this->logsModel()->deleteIds((array) $this->input->get('cid', [], 'int'));

        if ($count > 0) {
            LogHelper::add(['action' => 'log_deleted', 'severity' => 1, 'new_value' => (string) $count]);
        }

        $this->setMessage(Text::plural('COM_STEALTHWATCH_N_ITEMS_DELETED', $count));
        $this->redirectToList();
    }

    public function purge(): void
    {
        $this->checkToken();
        $this->assertCanDelete();

        $count = LogHelper::purge();

        if ($count > 0) {
            LogHelper::add(['action' => 'log_purged', 'severity' => 0, 'new_value' => (string) $count]);
        }

        $this->setMessage(Text::plural('COM_STEALTHWATCH_N_ITEMS_PURGED', $count));
        $this->redirectToList();
    }

    public function clear(): void
    {
        $this->checkToken();
        $this->assertCanDelete();

        $count = $this->logsModel()->clearAll();

        LogHelper::add(['action' => 'log_cleared', 'severity' => 1, 'new_value' => (string) $count]);

        $this->setMessage(Text::plural('COM_STEALTHWATCH_N_ITEMS_DELETED', $count));
        $this->redirectToList();
    }

    private function assertCanDelete(): void
    {
        if (!AccessHelper::canDeleteLogs($this->app->getIdentity())) {
            LogHelper::add(['action' => 'blocked', 'severity' => 1, 'title' => 'Stealth Watch log', 'old_value' => 'delete log entries']);

            throw new NotAllowed(Text::_('JLIB_APPLICATION_ERROR_DELETE_NOT_PERMITTED'), 403);
        }
    }

    private function logsModel(): LogsModel
    {
        return $this->getModel('Logs', 'Administrator', ['ignore_request' => true]);
    }

    private function redirectToList(): void
    {
        $this->setRedirect(Route::_('index.php?option=com_stealthwatch&view=logs', false));
    }
}
