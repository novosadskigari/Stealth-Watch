<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

namespace Joomla\Component\StealthWatch\Administrator\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Component\StealthWatch\Administrator\Helper\LogHelper;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

class LogsModel extends ListModel
{
    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'created', 'a.created',
                'username', 'a.username',
                'action', 'a.action',
                'title', 'a.title',
                'tag', 'a.tag',
                'plugin', 'user_id', 'period',
            ];
        }

        parent::__construct($config, $factory);
    }

    protected function populateState($ordering = 'a.created', $direction = 'DESC')
    {
        parent::populateState($ordering, $direction);
    }

    protected function getStoreId($id = '')
    {
        foreach (['search', 'action', 'plugin', 'user_id', 'tag', 'period'] as $filter) {
            $id .= ':' . $this->getState('filter.' . $filter);
        }

        return parent::getStoreId($id);
    }

    protected function getListQuery(): QueryInterface
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('a.*')
            ->from($db->quoteName(LogHelper::TABLE, 'a'));

        // Free-text search
        $search = trim((string) $this->getState('filter.search'));

        if ($search !== '') {
            if (stripos($search, 'id:') === 0) {
                $id = (int) substr($search, 3);
                $query->where($db->quoteName('a.id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            } else {
                $like = '%' . $search . '%';
                $query->where(
                    '(' . $db->quoteName('a.title') . ' LIKE :s1'
                    . ' OR ' . $db->quoteName('a.element') . ' LIKE :s2'
                    . ' OR ' . $db->quoteName('a.username') . ' LIKE :s3'
                    . ' OR ' . $db->quoteName('a.user_email') . ' LIKE :s4'
                    . ' OR ' . $db->quoteName('a.ip_address') . ' LIKE :s5)'
                )
                    ->bind(':s1', $like)
                    ->bind(':s2', $like)
                    ->bind(':s3', $like)
                    ->bind(':s4', $like)
                    ->bind(':s5', $like);
            }
        }

        // Action
        $action = (string) $this->getState('filter.action');

        if ($action === 'log') {
            $query->where($db->quoteName('a.action') . ' LIKE ' . $db->quote('log\_%'));
        } elseif ($action !== '') {
            $query->where($db->quoteName('a.action') . ' = :action')->bind(':action', $action);
        }

        // Plugin (value is "folder/element")
        $plugin = (string) $this->getState('filter.plugin');

        if (str_contains($plugin, '/')) {
            [$folder, $element] = explode('/', $plugin, 2);
            $query->where($db->quoteName('a.folder') . ' = :folder')
                ->where($db->quoteName('a.element') . ' = :element')
                ->bind(':folder', $folder)
                ->bind(':element', $element);
        }

        // User (0 = guest)
        $userId = (string) $this->getState('filter.user_id');

        if ($userId !== '' && ctype_digit($userId)) {
            $uid = (int) $userId;
            $query->where($db->quoteName('a.user_id') . ' = :uid')->bind(':uid', $uid, ParameterType::INTEGER);
        }

        // Type tag
        $tag = (string) $this->getState('filter.tag');

        if ($tag === 'none') {
            $query->where($db->quoteName('a.tag') . ' = ' . $db->quote(''));
        } elseif ($tag !== '') {
            $query->where($db->quoteName('a.tag') . ' = :tag')->bind(':tag', $tag);
        }

        // Period in days
        $period = (int) $this->getState('filter.period');

        if ($period > 0) {
            $since = Factory::getDate()->sub(new \DateInterval('P' . $period . 'D'))->toSql();
            $query->where($db->quoteName('a.created') . ' >= :since')->bind(':since', $since);
        }

        $orderCol = $this->getState('list.ordering', 'a.created');
        $orderDir = strtoupper((string) $this->getState('list.direction', 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $query->order($db->escape($orderCol) . ' ' . $orderDir)
            ->order($db->quoteName('a.id') . ' ' . $orderDir);

        return $query;
    }

    public function deleteIds(array $ids): int
    {
        $ids = array_values(array_filter(array_map('intval', $ids)));

        if (!$ids) {
            return 0;
        }

        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->delete($db->quoteName(LogHelper::TABLE))
            ->whereIn($db->quoteName('id'), $ids);

        $db->setQuery($query)->execute();

        return (int) $db->getAffectedRows();
    }

    public function clearAll(): int
    {
        $db = $this->getDatabase();
        $db->setQuery($db->createQuery()->delete($db->quoteName(LogHelper::TABLE)))->execute();

        return (int) $db->getAffectedRows();
    }
}
