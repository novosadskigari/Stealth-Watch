CREATE TABLE IF NOT EXISTS "#__stealthwatch_log" (
  "id" serial NOT NULL,
  "created" timestamp without time zone NOT NULL,
  "action" varchar(30) DEFAULT '' NOT NULL,
  "severity" smallint DEFAULT 0 NOT NULL,
  "tag" varchar(30) DEFAULT '' NOT NULL,
  "extension_id" integer DEFAULT 0 NOT NULL,
  "title" varchar(255) DEFAULT '' NOT NULL,
  "folder" varchar(100) DEFAULT '' NOT NULL,
  "element" varchar(100) DEFAULT '' NOT NULL,
  "old_value" text,
  "new_value" text,
  "user_id" integer DEFAULT 0 NOT NULL,
  "username" varchar(150) DEFAULT '' NOT NULL,
  "user_email" varchar(100) DEFAULT '' NOT NULL,
  "ip_address" varchar(45) DEFAULT '' NOT NULL,
  "client" varchar(20) DEFAULT '' NOT NULL,
  "url" text,
  PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "#__stealthwatch_log_idx_created" ON "#__stealthwatch_log" ("created");
CREATE INDEX IF NOT EXISTS "#__stealthwatch_log_idx_user" ON "#__stealthwatch_log" ("user_id");
