DROP TABLE IF EXISTS `#__stealthwatch_log`;
