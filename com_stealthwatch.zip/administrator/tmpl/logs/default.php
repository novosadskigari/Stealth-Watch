<?php

/**
 * @package     com_stealthwatch
 * @author      Damir B
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\StealthWatch\Administrator\View\Logs\HtmlView $this */

$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('table.columns')->useScript('multiselect');

// Translucent tints + left accent: readable in both Atum light and dark mode
// (Bootstrap's table-warning forces a light background and breaks dark mode).
$wa->addInlineStyle('
#stealthwatchList tr.sw-row-alert > td { background-color: rgba(255, 193, 7, .08); }
#stealthwatchList tr.sw-row-alert > td:first-child { box-shadow: inset 4px 0 0 #e0a800; }
#stealthwatchList tr.sw-row-danger > td { background-color: rgba(220, 53, 69, .09); }
#stealthwatchList tr.sw-row-danger > td:first-child { box-shadow: inset 4px 0 0 #dc3545; }
#stealthwatchList tr.sw-row-override > td { background-color: rgba(13, 202, 240, .08); }
#stealthwatchList tr.sw-row-override > td:first-child { box-shadow: inset 4px 0 0 #0dcaf0; }
');

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

$actionBadges = [
    'disabled'    => 'bg-danger',
    'enabled'     => 'bg-success',
    'uninstalled' => 'bg-dark',
    'setting'     => 'bg-warning text-dark',
    'blocked'     => 'bg-danger',
    'reverted'    => 'bg-warning text-dark',
    'override'    => 'bg-info text-dark',
];

$tagBadges = [
    'jch_pagecache' => ['bg-danger', 'COM_STEALTHWATCH_TAG_JCH_PAGECACHE'],
    'jch'           => ['bg-info text-dark', 'COM_STEALTHWATCH_TAG_JCH'],
    'jch_setting'   => ['bg-warning text-dark', 'COM_STEALTHWATCH_TAG_JCH_SETTING'],
];

$maxText  = $this->maxEntries > 0 ? (string) $this->maxEntries : Text::_('COM_STEALTHWATCH_UNLIMITED');
$daysText = $this->retentionDays > 0 ? (string) $this->retentionDays : Text::_('COM_STEALTHWATCH_UNLIMITED');
?>
<form action="<?php echo Route::_('index.php?option=com_stealthwatch&view=logs'); ?>" method="post" name="adminForm" id="adminForm">
    <div class="row">
        <div class="col-md-12">
            <div id="j-main-container" class="j-main-container">
                <div class="text-muted small mb-2">
                    <div><?php echo Text::sprintf('COM_STEALTHWATCH_RETENTION_INFO', $maxText, $daysText); ?></div>
                    <div>
                        <?php echo Text::_($this->protectJch ? 'COM_STEALTHWATCH_PROTECTION_ON' : 'COM_STEALTHWATCH_PROTECTION_OFF'); ?>
                        &middot;
                        <?php echo $this->managerNames
                            ? Text::sprintf('COM_STEALTHWATCH_MANAGERS_INFO', $this->escape(implode(', ', $this->managerNames)))
                            : Text::_('COM_STEALTHWATCH_MANAGERS_NONE'); ?>
                    </div>
                </div>

                <?php echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]); ?>

                <?php if (empty($this->items)) : ?>
                    <div class="alert alert-info">
                        <span class="icon-info-circle" aria-hidden="true"></span>
                        <span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
                        <?php echo Text::_('COM_STEALTHWATCH_NO_ENTRIES'); ?>
                    </div>
                <?php else : ?>
                    <table class="table" id="stealthwatchList">
                        <caption class="visually-hidden"><?php echo Text::_('COM_STEALTHWATCH'); ?></caption>
                        <thead>
                            <tr>
                                <td class="w-1 text-center"><?php echo HTMLHelper::_('grid.checkall'); ?></td>
                                <th scope="col" class="w-15">
                                    <?php echo HTMLHelper::_('searchtools.sort', 'COM_STEALTHWATCH_HEADING_DATE', 'a.created', $listDirn, $listOrder); ?>
                                </th>
                                <th scope="col" class="w-10">
                                    <?php echo HTMLHelper::_('searchtools.sort', 'COM_STEALTHWATCH_HEADING_ACTION', 'a.action', $listDirn, $listOrder); ?>
                                </th>
                                <th scope="col">
                                    <?php echo HTMLHelper::_('searchtools.sort', 'COM_STEALTHWATCH_HEADING_ITEM', 'a.title', $listDirn, $listOrder); ?>
                                </th>
                                <th scope="col" class="w-15">
                                    <?php echo HTMLHelper::_('searchtools.sort', 'COM_STEALTHWATCH_HEADING_USER', 'a.username', $listDirn, $listOrder); ?>
                                </th>
                                <th scope="col" class="w-10 d-none d-md-table-cell"><?php echo Text::_('COM_STEALTHWATCH_HEADING_IP'); ?></th>
                                <th scope="col" class="w-20 d-none d-lg-table-cell"><?php echo Text::_('COM_STEALTHWATCH_HEADING_URL'); ?></th>
                                <th scope="col" class="w-5 d-none d-md-table-cell">
                                    <?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($this->items as $i => $item) :
                            $isAudit  = str_starts_with((string) $item->action, 'log_');
                            $rowClass = '';

                            if (\in_array($item->action, ['blocked', 'reverted'], true)) {
                                $rowClass = ' sw-row-danger';
                            } elseif ($item->action === 'override') {
                                $rowClass = ' sw-row-override';
                            } elseif ((int) $item->severity === 1) {
                                $rowClass = ' sw-row-alert';
                            }
                            ?>
                            <tr class="row<?php echo $i % 2; ?><?php echo $rowClass; ?>">
                                <td class="text-center">
                                    <?php echo HTMLHelper::_('grid.id', $i, $item->id, false, 'cid', 'cb', $item->title); ?>
                                </td>
                                <td class="text-nowrap">
                                    <?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC6')); ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo $actionBadges[$item->action] ?? 'bg-secondary'; ?>">
                                        <?php echo Text::_('COM_STEALTHWATCH_ACTION_' . strtoupper($item->action)); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if (isset($tagBadges[$item->tag])) : ?>
                                        <span class="badge <?php echo $tagBadges[$item->tag][0]; ?>"><?php echo Text::_($tagBadges[$item->tag][1]); ?></span>
                                    <?php endif; ?>

                                    <?php if ($isAudit) : ?>
                                        <?php echo Text::sprintf('COM_STEALTHWATCH_AUDIT_' . strtoupper($item->action), (int) $item->new_value); ?>
                                    <?php elseif ($item->extension_id && $item->folder !== '' && $item->action !== 'uninstalled') : ?>
                                        <a href="<?php echo Route::_('index.php?option=com_plugins&task=plugin.edit&extension_id=' . (int) $item->extension_id); ?>">
                                            <?php echo $this->escape($item->title); ?>
                                        </a>
                                    <?php else : ?>
                                        <?php echo $this->escape($item->title); ?>
                                    <?php endif; ?>

                                    <?php if ($item->folder !== '') : ?>
                                        <div class="small text-muted"><?php echo $this->escape($item->folder . '/' . $item->element); ?></div>
                                    <?php endif; ?>

                                    <?php if (\in_array($item->action, ['blocked', 'reverted', 'override'], true) && $item->old_value !== '') : ?>
                                        <div class="small"><?php echo Text::sprintf('COM_STEALTHWATCH_ATTEMPTED', $this->escape($item->old_value)); ?></div>
                                    <?php endif; ?>

                                    <?php if ($item->action === 'setting') : ?>
                                        <div class="small">
                                            <code><?php echo $this->escape($item->old_value); ?></code>
                                            &rarr;
                                            <code><?php echo $this->escape($item->new_value); ?></code>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ((int) $item->user_id > 0) : ?>
                                        <a href="<?php echo Route::_('index.php?option=com_users&task=user.edit&id=' . (int) $item->user_id); ?>">
                                            <?php echo $this->escape($item->username); ?>
                                        </a>
                                        <div class="small text-muted"><?php echo $this->escape($item->user_email); ?></div>
                                    <?php else : ?>
                                        <span class="text-danger"><?php echo Text::_('COM_STEALTHWATCH_GUEST'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="d-none d-md-table-cell">
                                    <?php echo $this->escape($item->ip_address); ?>
                                    <div class="small text-muted"><?php echo $this->escape($item->client); ?></div>
                                </td>
                                <td class="d-none d-lg-table-cell small text-break">
                                    <?php echo $this->escape((string) $item->url); ?>
                                </td>
                                <td class="d-none d-md-table-cell"><?php echo (int) $item->id; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php echo $this->pagination->getListFooter(); ?>
                <?php endif; ?>

                <input type="hidden" name="task" value="">
                <input type="hidden" name="boxchecked" value="0">
                <?php echo HTMLHelper::_('form.token'); ?>
            </div>
        </div>
    </div>
</form>
